# AllergyAlert
Java-based Android app for food allergy tracking.
